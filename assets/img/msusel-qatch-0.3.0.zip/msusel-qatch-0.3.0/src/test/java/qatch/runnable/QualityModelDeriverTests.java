package qatch.runnable;

import org.junit.Assert;
import org.junit.Test;
import qatch.TestHelper;
import qatch.analysis.Diagnostic;
import qatch.analysis.Finding;
import qatch.analysis.ITool;
import qatch.analysis.IToolLOC;
import qatch.model.Characteristic;
import qatch.model.Property;
import qatch.model.QualityModel;
import qatch.model.Tqi;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class QualityModelDeriverTests {

    @Test
    public void testDeriveModel() {

        // Configs
        Path qmDescriptionPath = Paths.get("src/test/resources/quality_models/qualityModel_test_description.json");
        Path benchmarkRepo = Paths.get("src/test/resources/benchmark_repository");
        Path comparisonMatricesDirectory = Paths.get("src/test/resources/comparison_matrices/test_derive_model");
        Path analysisResults = Paths.get("src/test/out/benchmark_results/benchmark_data.csv");
        Path rThresholdsOutput = Paths.get("src/test/out/r_thresholds");
        Path tempWeightsDirectory = Paths.get("src/test/out/weighter");
        String projectRootFlag = ".txt";

        // Initialize objects
        QualityModel qmDescription = new QualityModel(qmDescriptionPath);
        IToolLOC fakeLocTool = new IToolLOC() {
            @Override
            public Integer analyzeLinesOfCode(Path projectLocation) {
                return 50;
            }
            @Override
            public Path initialize(Path toolRoot) {
                return null;
            }
        };

        // (Make ITool to return different values for each project)
        ITool tool = new ITool() {
            @Override
            public Path analyze(Path projectLocation) {
                switch (projectLocation.getFileName().toString()) {
                    case "BenchmarkProjectOne":
                        return Paths.get("src/test/resources/tool_results/benchmark_one_results.xml");
                    case "BenchmarkProjectTwo":
                        return Paths.get("src/test/resources/tool_results/benchmark_two_results.xml");
                    case "BenchmarkProjectThree":
                        return Paths.get("src/test/resources/tool_results/benchmark_three_results.xml");
                    default:
                        throw new RuntimeException("switch statement default case");
                }
            }

            /*
             * Test info for reference and assertions:
             *
             * Project 01: Measure 01 = 0.005, Measure 02 = 0.005
             *      Measure 01, TST0001: 1 finding
             *      Measure 02, TST0003: 1 finding
             * Project 02: Measure 01 = 0.01, Measure 02 = 0.015
             *      Measure 01, TST0001: 1 finding
             *      Measure 01, TST0002: 1 finding
             *      Measure 02, TST0003: 1 finding
             *      Measure 02, TST0004: 1 finding
             *      Measure 02, TST0005: 1 finding
             * Project 03: Measure 01 = 0.02, Measure 02 = 0.03
             *      Measure 01, TST0001: 2 findings
             *      Measure 01, TST0002: 2 findings
             *      Measure 02, TST0003: 2 findings
             *      Measure 02, TST0004: 2 findings
             *      Measure 02, TST0005: 2 findings
             */
            @Override
            public Map<String, Diagnostic> parseAnalysis(Path toolResults) {
                Finding f1 = TestHelper.makeFinding("file/path/one", 11, 1);
                Finding f2 = TestHelper.makeFinding("file/path/two", 22, 2);

                Map<String, Diagnostic> diagnostics = new HashMap<>();
                switch (toolResults.getFileName().toString()) {
                    case "benchmark_one_results.xml":

                        Diagnostic bench1tst1 = new Diagnostic("TST0001", "Sample Description", "Sample Tool Name");
                        Diagnostic bench1tst3 = new Diagnostic("TST0003", "Sample Description", "Sample Tool Name");
                        bench1tst1.setFinding(f1);
                        bench1tst3.setFinding(f1);

                        diagnostics.put("TST0001", bench1tst1);
                        diagnostics.put("TST0003", bench1tst3);

                        return diagnostics;

                    case "benchmark_two_results.xml":
                        Diagnostic bench2tst1 = new Diagnostic("TST0001", "Sample Description", "Sample Tool Name");
                        Diagnostic bench2tst2 = new Diagnostic("TST0002", "Sample Description", "Sample Tool Name");
                        Diagnostic bench2tst3 = new Diagnostic("TST0003", "Sample Description", "Sample Tool Name");
                        Diagnostic bench2tst4 = new Diagnostic("TST0004", "Sample Description", "Sample Tool Name");
                        Diagnostic bench2tst5 = new Diagnostic("TST0005", "Sample Description", "Sample Tool Name");

                        bench2tst1.setFinding(f1);
                        bench2tst2.setFinding(f1);
                        bench2tst3.setFinding(f1);
                        bench2tst4.setFinding(f1);
                        bench2tst5.setFinding(f1);

                        diagnostics.put("TST0001", bench2tst1);
                        diagnostics.put("TST0002", bench2tst2);
                        diagnostics.put("TST0003", bench2tst3);
                        diagnostics.put("TST0004", bench2tst4);
                        diagnostics.put("TST0005", bench2tst5);

                        return diagnostics;

                    case "benchmark_three_results.xml":
                        Diagnostic bench3tst1 = new Diagnostic("TST0001", "Sample Description", "Sample Tool Name");
                        Diagnostic bench3tst2 = new Diagnostic("TST0002", "Sample Description", "Sample Tool Name");
                        Diagnostic bench3tst3 = new Diagnostic("TST0003", "Sample Description", "Sample Tool Name");
                        Diagnostic bench3tst4 = new Diagnostic("TST0004", "Sample Description", "Sample Tool Name");
                        Diagnostic bench3tst5 = new Diagnostic("TST0005", "Sample Description", "Sample Tool Name");

                        bench3tst1.setFindings(Stream.of(f1, f2).collect(Collectors.toSet()));
                        bench3tst2.setFindings(Stream.of(f1, f2).collect(Collectors.toSet()));
                        bench3tst3.setFindings(Stream.of(f1, f2).collect(Collectors.toSet()));
                        bench3tst4.setFindings(Stream.of(f1, f2).collect(Collectors.toSet()));
                        bench3tst5.setFindings(Stream.of(f1, f2).collect(Collectors.toSet()));

                        diagnostics.put("TST0001", bench3tst1);
                        diagnostics.put("TST0002", bench3tst2);
                        diagnostics.put("TST0003", bench3tst3);
                        diagnostics.put("TST0004", bench3tst4);
                        diagnostics.put("TST0005", bench3tst5);

                        return diagnostics;

                    default:
                        throw new RuntimeException("switch statement default case");
                }
            }

            @Override
            public Path initialize(Path toolRoot) {
                return null;
            }

            @Override
            public String getName() {
                return "Deriver Test Tool";
            }
        };

        Map<String, ITool> tools = new HashMap<String, ITool>() {{ put(tool.getName(), tool); }};

        // Run process
        QualityModel qm = QualityModelDeriver.deriveModel(
                qmDescription, fakeLocTool, tools, benchmarkRepo, comparisonMatricesDirectory, analysisResults,
                rThresholdsOutput, tempWeightsDirectory, projectRootFlag
        );

        // Assert
        Tqi tqi = qm.getTqi();
        Characteristic c1 = qm.getCharacteristic("Characteristic 01");
        Characteristic c2 = qm.getCharacteristic("Characteristic 02");
        Property p1 = qm.getProperty("Property 01");
        Property p2 = qm.getProperty("Property 02");

        Assert.assertEquals(0.6667, tqi.getWeight("Characteristic 01"), 0.0001);
        Assert.assertEquals(0.3333, tqi.getWeight("Characteristic 02"), 0.0001);

        Assert.assertEquals(0.25, c1.getWeight("Property 01"), 0.0001);
        Assert.assertEquals(0.75, c1.getWeight("Property 02"), 0.0001);
        Assert.assertEquals(0.8, c2.getWeight("Property 01"), 0.0001);
        Assert.assertEquals(0.2, c2.getWeight("Property 02"), 0.0001);

        Assert.assertArrayEquals(new Double[]{0.02, 0.04, 0.08}, p1.getThresholds());
        Assert.assertArrayEquals(new Double[]{0.02, 0.06, 0.12}, p2.getThresholds());
    }
}
