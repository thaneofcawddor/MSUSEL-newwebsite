package qatch.evaluation;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import qatch.TestHelper;
import qatch.analysis.Finding;
import qatch.analysis.Measure;
import qatch.model.Property;
import qatch.model.QualityModel;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ProjectTests {

    private Project p;
    private QualityModel qm;
    private double loc;

    @Before
    public void setUp()  {
        this.p = TestHelper.makeProject("TestProject");
        this.loc = this.p.getLinesOfCode();
        this.qm = this.p.getQualityModel();
    }


    @Test
    public void testEvaluateCharacteristics() {

        /*
         * Measure 01, TST0001: 1 finding
         * Measure 01, TST0002: 1 findings
         * Measure 02, TST0003: 1 findings
         * Measure 02, TST0004: 1 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);
        qm.setFinding(qm.getMeasure("Measure 02"), "TST0003", f1);
        qm.setFinding(qm.getMeasure("Measure 02"), "TST0004", f1);

        p.evaluateCharacteristics();

        Assert.assertEquals(0.3875, p.getQualityModel().getCharacteristic("Characteristic 01").getValue(loc), 0.001);
        Assert.assertEquals(0.40625, p.getQualityModel().getCharacteristic("Characteristic 02").getValue(loc), 0.001);
    }

    @Test
    public void testEvaluateProperties_negative_lowerGroup() {
        Property p1 = p.getQualityModel().getProperty("Property 01");
        Property p2 = p.getQualityModel().getProperty("Property 02");

        // 0 findings

        p.evaluateProperties();

        Assert.assertEquals(1.0, p1.getValue(loc), 0);
        Assert.assertEquals(1.0, p2.getValue(loc), 0);
    }

    @Test
    public void testEvaluateProperties_negative_middleGroup() {
        Property p1 = p.getQualityModel().getProperty("Property 01");

        /*
         * Measure 01, TST0001: 1 finding
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);

        p.evaluateProperties();

        Assert.assertEquals(0.46875, p1.getValue(loc), .001);
    }

    @Test
    public void testEvaluateProperties_negative_saturation() {
        Property p1 = p.getQualityModel().getProperty("Property 01");

        /*
         * Measure 01, TST0001: 4 findings
         * Measure 01, TST0002: 4 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);
        Finding f2 = TestHelper.makeFinding("file/path/f2", 222, 1);
        Finding f3 = TestHelper.makeFinding("file/path/f3", 333, 1);
        Finding f4 = TestHelper.makeFinding("file/path/f4", 444, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f2);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f3);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f4);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f2);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f3);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f4);

        p.evaluateProperties();

        Assert.assertEquals(0.0, p1.getValue(loc), 0);
    }

    @Test
    public void testEvaluateProperties_negative_upperGroup() {

        Property p1 = p.getQualityModel().getProperty("Property 01");

        /*
         * Measure 01, TST0001: 2 findings
         * Measure 01, TST0002: 1 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);
        Finding f2 = TestHelper.makeFinding("file/path/f2", 222, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f2);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);

        p.evaluateProperties();

        Assert.assertEquals(0.15625, p1.getValue(loc), .000001);
    }

    @Test
    public void testEvaluateProperties_positive_lowerGroup() {
        Property p1 = p.getQualityModel().getProperty("Property 01");
        Property p2 = p.getQualityModel().getProperty("Property 02");

        p1.setPositive(true);
        p2.setPositive(true);

        // 0 findings

        p.evaluateProperties();

        Assert.assertEquals(0, p1.getValue(loc), 0);
        Assert.assertEquals(0, p2.getValue(loc), 0);
    }

    @Test
    public void testEvaluateProperties_positive_middleGroup() {
        Property p1 = p.getQualityModel().getProperty("Property 01");
        Property p2 = p.getQualityModel().getProperty("Property 02");

        p1.setPositive(true);
        p2.setPositive(true);

        /*
         * Measure 01, TST0001: 1 finding
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);

        p.evaluateProperties();

        Assert.assertEquals(0.53125, p1.getValue(loc), .001);
    }

    @Test
    public void testEvaluateProperties_positive_saturation() {
        Property p1 = p.getQualityModel().getProperty("Property 01");
        Property p2 = p.getQualityModel().getProperty("Property 02");

        p1.setPositive(true);
        p2.setPositive(true);

        /*
         * Measure 01, TST0001: 4 findings
         * Measure 01, TST0002: 4 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);
        Finding f2 = TestHelper.makeFinding("file/path/f2", 222, 1);
        Finding f3 = TestHelper.makeFinding("file/path/f3", 333, 1);
        Finding f4 = TestHelper.makeFinding("file/path/f4", 444, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f2);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f3);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f4);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f2);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f3);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f4);

        p.evaluateProperties();

        Assert.assertEquals(1.0, p1.getValue(loc), 0);
    }

    @Test
    public void testEvaluateProperties_positive_upperGroup() {
        Property p1 = p.getQualityModel().getProperty("Property 01");
        Property p2 = p.getQualityModel().getProperty("Property 02");

        p1.setPositive(true);
        p2.setPositive(true);

        /*
         * Measure 01, TST0001: 2 findings
         * Measure 01, TST0002: 1 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);
        Finding f2 = TestHelper.makeFinding("file/path/f2", 222, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f2);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);

        p.evaluateProperties();

        Assert.assertEquals(0.84375, p1.getValue(loc), .001);
    }

    @Test
    public void testEvaluateTqi() {

        /*
         * Measure 01, TST0001: 1 finding
         * Measure 01, TST0002: 1 findings
         * Measure 02, TST0003: 1 findings
         * Measure 02, TST0004: 1 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);
        qm.setFinding(qm.getMeasure("Measure 02"), "TST0003", f1);
        qm.setFinding(qm.getMeasure("Measure 02"), "TST0004", f1);

        p.evaluateTqi();

        Assert.assertEquals(0.39125, p.getQualityModel().getTqi().getValue(loc), 0.001);

    }

    @Test
    public void testExportEvaluation() throws IOException {
        Path exportLocation = Paths.get("src/test/out/TestExportEval");

        /*
         * Measure 01, TST0001: 1 finding
         * Measure 01, TST0002: 1 findings
         * Measure 02, TST0003: 1 findings
         * Measure 02, TST0004: 1 findings
         */
        Finding f1 = TestHelper.makeFinding("file/path/f1", 111, 1);

        qm.setFinding(qm.getMeasure("Measure 01"), "TST0001", f1);
        qm.setFinding(qm.getMeasure("Measure 01"), "TST0002", f1);
        qm.setFinding(qm.getMeasure("Measure 02"), "TST0003", f1);
        qm.setFinding(qm.getMeasure("Measure 02"), "TST0004", f1);

        p.evaluateTqi();

        Path result = p.exportToJson(exportLocation);
        FileReader fr = new FileReader(result.toString());
        JsonObject jsonResults = new JsonParser().parse(fr).getAsJsonObject();
        fr.close();
        FileUtils.forceDelete(exportLocation.toFile());

        JsonObject additionalData = jsonResults.getAsJsonObject("additionalData");
        JsonObject jsonTqi = jsonResults.getAsJsonObject("tqi");
        JsonObject jsonCharacteristics = jsonResults.getAsJsonObject("characteristics");
        JsonObject jsonChar01 = jsonCharacteristics.getAsJsonObject("Characteristic 01");
        JsonObject jsonChar02 = jsonCharacteristics.getAsJsonObject("Characteristic 02");
        JsonObject jsonProperties = jsonResults.getAsJsonObject("properties");
        JsonObject jsonProperty01 = jsonProperties.getAsJsonObject("Property 01");
        JsonObject jsonProperty02 = jsonProperties.getAsJsonObject("Property 02");
        JsonObject jsonMeasure01 = jsonProperty01.getAsJsonObject("measure");
        JsonObject jsonMeasure02 = jsonProperty02.getAsJsonObject("measure");

        Assert.assertEquals("TestProject", additionalData.getAsJsonPrimitive("projectName").getAsString());
        Assert.assertEquals("200", additionalData.getAsJsonPrimitive("projectLinesOfCode").getAsString());

        Assert.assertEquals("Test QM", jsonResults.getAsJsonPrimitive("name").getAsString());

        Assert.assertEquals("Total Quality", jsonTqi.getAsJsonPrimitive("name").getAsString());
        Assert.assertEquals(0.39125, jsonTqi.getAsJsonPrimitive("value").getAsFloat(), 0.0001);
        Assert.assertEquals(0.8, jsonTqi.getAsJsonObject("weights").getAsJsonPrimitive("Characteristic 01").getAsDouble(), 0.0001);
        Assert.assertEquals(0.2, jsonTqi.getAsJsonObject("weights").getAsJsonPrimitive("Characteristic 02").getAsDouble(), 0.0001);

        Assert.assertEquals(0.3875, jsonChar01.getAsJsonPrimitive("value").getAsFloat(), 0.0001);
        Assert.assertEquals(0.6, jsonChar01.getAsJsonObject("weights").getAsJsonPrimitive("Property 01").getAsDouble(), 0.0001);
        Assert.assertEquals(0.4, jsonChar01.getAsJsonObject("weights").getAsJsonPrimitive("Property 02").getAsDouble(), 0.0001);

        Assert.assertEquals(0.40625, jsonChar02.getAsJsonPrimitive("value").getAsFloat(), 0.0001);
        Assert.assertEquals(0.5, jsonChar02.getAsJsonObject("weights").getAsJsonPrimitive("Property 01").getAsDouble(), 0.0001);
        Assert.assertEquals(0.5, jsonChar02.getAsJsonObject("weights").getAsJsonPrimitive("Property 02").getAsDouble(), 0.0001);

        Assert.assertEquals(0.3125, jsonProperty01.getAsJsonPrimitive("value").getAsFloat(), 0.0001);
        Assert.assertEquals(0.0, jsonProperty01.getAsJsonArray("thresholds").get(0).getAsFloat(), 0.0001);
        Assert.assertEquals(0.004, jsonProperty01.getAsJsonArray("thresholds").get(1).getAsFloat(), 0.0001);
        Assert.assertEquals(0.02, jsonProperty01.getAsJsonArray("thresholds").get(2).getAsFloat(), 0.0001);

        Assert.assertEquals(0.5, jsonProperty02.getAsJsonPrimitive("value").getAsFloat(), 0.0001);
        Assert.assertEquals(0.0, jsonProperty02.getAsJsonArray("thresholds").get(0).getAsFloat(), 0.0001);
        Assert.assertEquals(0.01, jsonProperty02.getAsJsonArray("thresholds").get(1).getAsFloat(), 0.0001);
        Assert.assertEquals(0.02, jsonProperty02.getAsJsonArray("thresholds").get(2).getAsFloat(), 0.0001);

        Assert.assertEquals(0.01, jsonMeasure01.getAsJsonPrimitive("value").getAsFloat(), 0.0001);
        Assert.assertEquals(0.01, jsonMeasure02.getAsJsonPrimitive("value").getAsFloat(), 0.0001);

    }

    /*
     * Test state of fields of project object immediately after construction
     */
    @Test
    public void testProjectConstructor() {
        String name = "Test Project";
        Path path = Paths.get("test/path");
        QualityModel qm = TestHelper.makeQualityModel();

        Project project = new Project(name, path, qm);

        // Assertions
        Assert.assertEquals(name, project.getName());
        Assert.assertEquals(path, project.getPath());

        // Assert tree structure pass-by-reference from TQI root node compared to fields
        project.getQualityModel().getTqi().getCharacteristics().values().forEach(tqiCharacteristic -> {
            // Characteristic layer
            Assert.assertEquals(project.getQualityModel().getCharacteristics().get(tqiCharacteristic.getName()), tqiCharacteristic);
            tqiCharacteristic.getProperties().values().forEach(tqiProperty -> {
                // Properties layer
                Assert.assertEquals(project.getQualityModel().getProperties().get(tqiProperty.getName()), tqiProperty);
                Measure projectMeasure = project.getQualityModel().getProperties().get(tqiProperty.getName()).getMeasure();
                // Property's measure
                Assert.assertEquals(projectMeasure, tqiProperty.getMeasure());
                tqiProperty.getMeasure().getDiagnostics().forEach(tqiDiagnostic -> {
                    // Measure's diagnostics
                    Assert.assertEquals(projectMeasure.getDiagnostic(tqiDiagnostic.getName()), tqiDiagnostic);
                });
            });
        });

    }
}
